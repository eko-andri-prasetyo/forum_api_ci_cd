const DetailReply = require('../DetailReply');

describe('a DetailReply entities', () => {
  it('should create entity correctly and replace content when deleted', () => {
    const detailReply = new DetailReply({
      id: 'reply-123',
      commentId: 'comment-123',
      username: 'dicoding',
      date: '2021-08-08T07:59:48.766Z',
      content: 'sebuah balasan',
      isDelete: true,
    });

    expect(detailReply.id).toEqual('reply-123');
    expect(detailReply.commentId).toEqual('comment-123');
    expect(detailReply.content).toEqual('**balasan telah dihapus**');
  });
});