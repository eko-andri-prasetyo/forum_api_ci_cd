const DetailComment = require('../DetailComment');

describe('a DetailComment entities', () => {
  it('should create entity correctly and replace content when deleted', () => {
    const detailComment = new DetailComment({
      id: 'comment-123',
      username: 'dicoding',
      date: '2021-08-08T07:59:48.766Z',
      content: 'sebuah comment',
      isDelete: true,
      replies: [],
    });

    expect(detailComment.id).toEqual('comment-123');
    expect(detailComment.content).toEqual('**komentar telah dihapus**');
  });
});
